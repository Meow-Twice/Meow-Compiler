package backend;

public class Parallel {
}
