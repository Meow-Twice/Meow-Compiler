package descriptor;

public interface Descriptor {
    StringBuilder getOutput();
    void clear();
}
