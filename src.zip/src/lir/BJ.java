package lir;

public class BJ extends MachineInst{
}
