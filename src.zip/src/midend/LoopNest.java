package midend;

import mir.BasicBlock;

import java.util.ArrayList;

public class LoopNest {

    private BasicBlock entryBB;
    private ArrayList<BasicBlock> BBs;
    private BasicBlock next;


}
