package midend;

public class OutParam {

    public static final boolean ONLY_OUTPUT_PRE_SUC = false;
    public static final boolean BB_NEED_CFG_INFO = false;
    public static final boolean BB_NEED_LOOP_INFO = false;
    public static final boolean COND_CNT_DEBUG_FOR_LC = false;

    public static final boolean NEED_BB_USE_IN_BR_INFO = false;

}
