package midend;

public class TestMain {
    //fixme:test
    public static void main(String[] args) {
        // System.out.printf("%x",Double.doubleToRawLongBits((float) 1.3));
        // //input TOP TODO:修改传参格式
        // ArrayList<Function> functions = new ArrayList<>();
        //
        // //TODO:前端调用方法
        // MidEndRunner midEndRunner = new MidEndRunner(functions);
        // midEndRunner.Run();
        // Value v = new Instr.Jump(new BasicBlock(), new BasicBlock());
        // int n = 1000000000;
        // long first = System.nanoTime();
        // for(int i = 0; i < n;i ++){
        //     assert Jump() instanceof Instr.Jump;
        // }
        // long end = System.nanoTime();
        // System.out.println(end - first);
        // first = System.nanoTime();
        // for(int i = 0; i < n;i ++){
        //     assert ((Instr.Jump) Jump()).tag== Instr.Tag.j;
        // }
        // end = System.nanoTime();
        // System.out.println(end - first);
    }

    // public static Value Jump(){
    //     return new Instr.Jump(new BasicBlock(), new BasicBlock());
    // }
}
