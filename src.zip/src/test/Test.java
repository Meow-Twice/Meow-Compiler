package test;

import backend.CodeGen;

public class Test {
    public static void main(String[] args) {
        // float a = (float) 1.3;
        // String fa = String.valueOf(Float.floatToIntBits(a));
        // System.out.println(fa);
        // long b = 0x400E691E600000L;
        // System.out.println(Long.toHexString(b));
        // System.out.println(Double.longBitsToDouble(b));
        // int bb = 1065353216;
        // System.out.println(String.format("%f\n",Float.intBitsToFloat((int) bb)));
        // System.out.println(String.format("%a\n",Float.intBitsToFloat((int) bb)));
        // float input = Float.parseFloat("0x0.00000bed532d4p-1022");
        // System.out.println("f:\t"+input);
        // float PI = 03.141592653589793f;
        // float ans = PI * input * input;
        // System.out.println(ans);
        // System.out.println("i:\t"+(int)fb);
        // int ib = Float.floatToIntBits(fb);
        // System.out.println(ib);
        // long l = ib;
        // System.out.println(l);
        // System.out.println(l << 32 >>> 32);
        // System.out.println((int) (l << 32 >>> 32));
        // System.out.println(l << 32 >> 32);
        // l = l << 32 >>> 32;
        // int il = (int) l;
        // System.out.println(il);
        // System.out.println(Float.intBitsToFloat(il));
        // System.out.println(CodeGen.immCanCode(1028));
    }

}
