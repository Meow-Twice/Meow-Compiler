package util;

public class CenterControl {
    public static boolean _FAST_REG_ALLOCATE = false;
    public static boolean _IMM_TRY = false;
    public static boolean _ONLY_FRONTEND = false;
}
